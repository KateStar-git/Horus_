public interface Block {
    String getColor();
    String getMaterial();
}
